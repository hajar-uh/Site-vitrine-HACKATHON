Hi,
Thanks for Downloading our item

—

This free font only has a license "PERSONAL USE" only , if you want to use it for commercial purposes you can buy our font.

—

now we have the best offer - Massive Collection Fonts Bundle is here with an incredible selection of 250+ fonts 

—

This font and All of our best fonts with "FULL GLYPHS/FEATURE" dan including this font . This bundle includes premium fonts and is valued at a staggering $2568. But you can get it now for only $9 

—

link bundle —> https://www.creativefabrica.com/product/massive-collection-fonts-bundle/ref/379256

—

with "COMMERCIAL USE LICENSES"
This font is included in the bundle

—

if you want to ask something or ask for a extended license about this font, 
you can contact us via email : Vunira.project@gmail.com


Thank you :)